package com.tm.orientdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import com.orientechnologies.orient.core.config.OGlobalConfiguration;
import com.orientechnologies.orient.core.db.document.ODatabaseDocumentTx;
import com.orientechnologies.orient.jdbc.OrientJdbcConnection;

public class MainClass {
	public static void main(String[] args) {
		
		Properties info = new Properties();
        String user = "root";
        String password = "root";
        ODatabaseDocumentTx db = new ODatabaseDocumentTx("plocal:databases/mydb"); 
        //D:\Tech M\SRIMS\OrientDB\orientdb-community-2.2.6\orientdb-community-2.2.6\databases
        db.open("roort", "root");
        OGlobalConfiguration.STORAGE_KEEP_OPEN.setValue( false );
        
        info.put("user", user);
        info.put("password", password);
        String query1 = "insert into Emp(empid,empname,empsalary) values ('101','Rod','50000s')";
        
        try {
			Class.forName("com.orientechnologies.orient.jdbc.OrientJdbcDriver");
			Connection connection = (OrientJdbcConnection) DriverManager.getConnection("jdbc:orient:plocal:databases/mydb", info);
			Statement statement = connection.createStatement();
			int upd1 = statement.executeUpdate(query1);
			
			if(upd1 == 0){
				System.out.println("Data inserted successfully");
				statement.close();
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
        
	}

}
