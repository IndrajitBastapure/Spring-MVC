package com.tm.dao;

import java.util.List;

import com.tm.pojo.Employee;

public interface EmployeeDAO {

	public List<Employee> getAllEmployees();
	//public int addEmployee(Employee employee);
	public void addEmployee(Employee employee);
	//public void getEmployeeDetails(Integer id);
	
	public Employee searchEmployee(Integer id );
	public void deleteEmployee(Integer id);
	public Employee updateEmployee(Employee employee);
}
