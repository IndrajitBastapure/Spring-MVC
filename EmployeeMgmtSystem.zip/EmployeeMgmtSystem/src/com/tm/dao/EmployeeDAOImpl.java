package com.tm.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.tm.controller.DBConnection;
import com.tm.pojo.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	DBConnection dbconn;
	Connection conn;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;

	public EmployeeDAOImpl() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			this.conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@your remote ip",
					"username", "password");
		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}

		
	}

	@Override
	public void addEmployee(Employee employee) {

		try {
			pstmt = conn
					.prepareStatement("insert into employee values(?,?,?,?)");
			pstmt.setInt(1, employee.getId());
			pstmt.setString(2, employee.getFirstName());
			pstmt.setString(3, employee.getLastName());
			pstmt.setDate(4, (java.sql.Date) employee.getBirthDate());
			int upd1 = pstmt.executeUpdate();

			if (upd1 != 0) {
				System.out.println("your data inserted successfully...");
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		List<Employee> employees = new ArrayList<Employee>();
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from employee");
			while (rs.next()) {
				Employee emp = new Employee();

				int id = rs.getInt("EMPID");
				String fname = rs.getString("EMPFNAME");
				String lname = rs.getString("EMPLNAME");
				Date dob = rs.getDate("EMPDOB");

				System.out.println("Id: " + id);
				System.out.println("First name: " + fname);
				System.out.println("Last name: " + lname);
				System.out.println("DOB: " + dob);

				emp.setId(rs.getInt("EMPID"));
				emp.setFirstName(rs.getString("EMPFNAME"));
				emp.setLastName(rs.getString("EMPLNAME"));
				emp.setBirthDate(rs.getDate("EMPDOB"));

				employees.add(emp);
			}

		} catch (SQLException e) {
			System.out.println(e);
		}

		return employees;
	}

	@Override
	public Employee searchEmployee(Integer id) {

		System.out.println("Inside search method...");
		System.out.println("Emp Id: " + id);

		Employee e = new Employee();

		try {
			pstmt = conn.prepareStatement("select * from employee where EMPID=?");
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				e.setId(rs.getInt("EMPID"));
				e.setFirstName(rs.getString("EMPFNAME"));
				e.setLastName(rs.getString("EMPLNAME"));
				e.setBirthDate(rs.getDate("EMPDOB"));
			} else {
				if (!rs.next()) {
					System.out.println("Employee record not found...");
				}
			}

		} catch (Exception exp) {
			System.out.println(exp);
		}
		return e;
	}

	@Override
	public void deleteEmployee(Integer id) {

		System.out.println("Inside delete method...");
		System.out.println("Emp Id: " + id);

		String delQuery = "delete from employee where EMPID=?";
		try {
			pstmt = conn.prepareStatement(delQuery);
			pstmt.setInt(1, id);
			int delres = pstmt.executeUpdate();

			if (delres != 0) {
				System.out.println("Employee deleted successfully..");
			}

		} catch (SQLException e) {
			System.out.println(e);
		}
	}

	@Override
	public Employee updateEmployee(Employee employee) {

		System.out.println("Inside update method...");
		//System.out.println("Emp Id: " + id);

		//Employee upemp = new Employee();
		

		try {
			String upQuery = "update employee set EMPFNAME=?,EMPLNAME=?,EMPDOB=? where EMPID=?";
			pstmt = conn.prepareStatement(upQuery);
			pstmt.setString(1, employee.getFirstName());
			pstmt.setString(2, employee.getLastName());
			pstmt.setDate(3, (java.sql.Date) employee.getBirthDate());
			pstmt.setInt(4, employee.getId());
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return employee;
	}

}
