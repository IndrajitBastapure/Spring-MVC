package com.tm.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.tm.pojo.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	@Override
	public List<Employee> getAllEmployees() {
		
		List<Employee> employees = new ArrayList<Employee>();
		
		Employee emp1 = new Employee();
		emp1.setId(101);
		emp1.setFirstName("Patrick");
		emp1.setLastName("Desouza");
		
		Employee emp2 = new Employee();
		emp2.setId(102);
		emp2.setFirstName("Joseph");
		emp2.setLastName("Deaniel");
		
		Employee emp3 = new Employee();
		emp3.setId(103);
		emp3.setFirstName("Merry");
		emp3.setLastName("Galvin");
		
		Employee emp4 = new Employee();
		emp4.setId(104);
		emp4.setFirstName("Rob");
		emp4.setLastName("Vittori");
		
		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
		employees.add(emp4);
		
		return employees;
	}

}
