package com.tm.controller;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tm.pojo.Employee;
import com.tm.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired(required = true)
	EmployeeService service;
	
	@RequestMapping("/getAllEmployees")
		public String getAllEmployees(Model model){
		
		model.addAttribute("employees", service.getAllEmployees());
		return "employeesListDisplay";
	}
	
	
	@RequestMapping("/addEmployee")
	public String addEmployee(@RequestParam("id") Integer id,
							  @RequestParam("firstName") String firstName,
							  @RequestParam("lastName") String lastName,
							  @RequestParam("birthDate") Date birthDate,
							  Model model,Employee empl){
		
		model.addAttribute("id", id);
		model.addAttribute("firstName", firstName);
		model.addAttribute("lastName", lastName);
		model.addAttribute("birthDate",birthDate);
		
		empl.setId(id);
		empl.setFirstName(firstName);
		empl.setLastName(lastName);
		empl.setBirthDate(birthDate);
		service.addEmployee(empl);
		
		return "success";
}
	
	
	@RequestMapping("/addEmpl")
	public String showaddEmpl(Model model){
		
		return "addEmployee";
	}
	
	
	@RequestMapping("/searchEmployee")
	public String searchEmployee(@RequestParam("id") Integer id,
							  Model model,Employee empl){
		
		model.addAttribute("id", id);
		empl.setId(id);
	
		model.addAttribute("searchempl", service.searchEmployee(id));
		
		return "searchsuccess";
}
	
	@RequestMapping("/searchEmpl")
	public String showsearchEmpl(Model model){
		
		return "searchEmployee";
	}
	
	
	
	@RequestMapping("/success")
	public String success(Model model){
		
		return "success";
	}
	
}
