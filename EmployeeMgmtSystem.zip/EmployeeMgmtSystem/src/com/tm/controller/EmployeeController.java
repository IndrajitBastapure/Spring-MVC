package com.tm.controller;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.tm.pojo.Employee;
import com.tm.service.EmployeeService;

@Controller
//@SessionAttributes("employee")
public class EmployeeController {

	@Autowired(required = true)
	EmployeeService service;
	
	@RequestMapping("/getAllEmployees")
		public String getAllEmployees(Model model){
		
		model.addAttribute("employees", service.getAllEmployees());
		return "employeesListDisplay";
	}
	
	
	@RequestMapping("/addEmployee")
	public String addEmployee(@ModelAttribute("employee") Employee empl,Model model){
		
		Employee emp = new Employee();
		model.addAttribute("employee", emp);
		
		System.out.println(empl.getId());
		System.out.println(empl.getFirstName());
		System.out.println(empl.getLastName());
		
		return "addEmployee";
}
	
	@RequestMapping("/success")
	public String success(Model model){
		
		return "success";
	}
	
}
