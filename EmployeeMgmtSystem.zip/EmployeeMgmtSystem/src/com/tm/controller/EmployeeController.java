package com.tm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tm.pojo.Employee;
import com.tm.service.EmployeeService;

@Controller
//@SessionAttributes("employee")
public class EmployeeController {

	@Autowired(required = true)
	EmployeeService service;
	
	@RequestMapping("/getAllEmployees")
		public String getAllEmployees(Model model){
		
		model.addAttribute("employees", service.getAllEmployees());
		return "employeesListDisplay";
	}
	
	
	@RequestMapping("/addEmployee")
	public String addEmployee(@RequestParam("id") Integer id,
							  @RequestParam("firstName") String firstName,
							  @RequestParam("lastName") String lastName,
							  Model model,Employee empl){
		/*Employee emp = new Employee();
		model.addAttribute("employee", emp);*/
		
		model.addAttribute("id", id);
		model.addAttribute("firstName", firstName);
		model.addAttribute("lastName", lastName);
		
		/*System.out.println(id);
		System.out.println(firstName);
		System.out.println(lastName);*/
		
		//Employee emp = new Employee();
		empl.setId(id);
		empl.setFirstName(firstName);
		empl.setLastName(lastName);
		service.addEmployee(empl);
		
		return "success";
}
	
	
	@RequestMapping("/addEmpl")
	public String showaddEmpl(Model model){
		
		return "addEmployee";
	}
	
	
	@RequestMapping("/success")
	public String success(Model model){
		
		return "success";
	}
	
}
