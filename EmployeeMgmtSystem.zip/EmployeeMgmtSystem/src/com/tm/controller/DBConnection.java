package com.tm.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {
	
	private Connection connection;
	public DBConnection() throws ClassNotFoundException, SQLException {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		this.connection = DriverManager.getConnection("jdbc:oracle:thin:@172.21.58.115:1521:XE", "srims_practice","srims_practice");
	}
	
	public Connection getConnection(){
		return this.connection;
	}
	
	/*public static DBConnection getConnection1(){
		
		Connection conn;
		Statement stmt;
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			conn = DriverManager.getConnection("jdbc:oracle:thin:@172.21.58.115:1521:XE", "srims_practice","srims_practice");
			stmt = conn.createStatement();
			int updt1 = stmt.executeUpdate("insert into employee values (101,'Rod','Johnson',TO_DATE('1983/05/03','YYYY/MM/DD'))");
			
			if(updt1!=0){
				System.out.println("Record inserted successfully.....");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		
		return new DBConnection();
		
	}
	*/
	

}
