package com.tm.service;

import java.util.List;

import com.tm.pojo.Employee;

public interface EmployeeService {

	public List<Employee> getAllEmployees();
	public void addEmployee(Employee employee);
	public Employee searchEmployee(Integer id );
}
