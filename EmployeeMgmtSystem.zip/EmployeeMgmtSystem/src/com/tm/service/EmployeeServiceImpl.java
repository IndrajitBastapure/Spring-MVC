package com.tm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.tm.dao.EmployeeDAO;
import com.tm.pojo.Employee;

@Service
@Component
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDAO dao;
	
	@Override
	public void addEmployee(Employee employee) {
		
		dao.addEmployee(employee);
	}
	
	@Override
	public List<Employee> getAllEmployees() {
		
		return dao.getAllEmployees();
	}

}
