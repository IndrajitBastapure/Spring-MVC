package com.tm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.tm.dao.EmployeeDAO;
import com.tm.pojo.Employee;

@Service
@Component
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDAO dao;
	
	@Override
	public void addEmployee(Employee employee) {
		
		dao.addEmployee(employee);
	}
	
	@Override
	public List<Employee> getAllEmployees() {
		
		return dao.getAllEmployees();
	}

	@Override
	public Employee searchEmployee(Integer id) {
		return dao.searchEmployee(id);
	}

	@Override
	public void deleteEmployee(Integer id) {
		dao.deleteEmployee(id);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		return dao.updateEmployee(employee);
	}

}
